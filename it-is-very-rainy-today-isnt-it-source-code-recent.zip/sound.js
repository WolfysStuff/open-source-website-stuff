rainsound = new Audio('sound.ogg'); 
if (typeof rainsound.loop == 'boolean')
{
    rainsound.loop = true;
}
else
{
    rainsound.addEventListener('ended', function() {
        this.currentTime = 0;
        this.play();
    }, false);
}
rainsound.play();